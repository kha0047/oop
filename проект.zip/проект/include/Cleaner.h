#pragma once
#include "Employee.h"
#include <iostream>
using namespace std;

class Cleaner : public Employee {
private:
    int floorAssigned;

public:
    Cleaner(const string& name, const string& surname, int phoneNumber, const string& emailAddress, int salary, int floor);

    void servis() override;
    void printInfo() const;
    void floorAssignedInfo() const;
};

